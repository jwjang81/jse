package cmm01.var;

public class PrimVar2 {

}
