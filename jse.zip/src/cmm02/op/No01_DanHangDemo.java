package cmm02.op;

public class No01_DanHangDemo {
	public static void main(String[] args) {
		//int i;  // 변수의 선언
		//i = 5; // 초기화, 할당
		
		int i = 5;
		i = i + 1;
		System.out.println("i = i + 1의 값 : " + i);
				
		int j = 5;
		j++;
		System.out.println("j++ 의 값 : " + j);
		
		
		int k = 5;
		++k;
		System.out.println("++k 의 값 : " + k);
		
	}
}



/*
  void main(){}  // 메소드 선언
   정의 : 바디 안에 알고리즘을 짜넣는것
   
   선언은 키워드 식별자 바디

 할당/초기화
   
   
  
   
 
 * */

class Abc{}  // 클래스 선언

