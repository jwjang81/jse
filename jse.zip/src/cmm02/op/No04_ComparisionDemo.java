package cmm02.op;

public class No04_ComparisionDemo {
	public static void main(String[] args) {
		int val01 = 1;
		int val02 = 2;
		
		if(val01 == val02){
			System.out.println("val01 == val02");
		}
		
		if(val01 != val02){
			System.out.println("val01 != val02");
		}
		
		if(val01 > val02){
			System.out.println("val01 > val02");
		}
		
		if(val01 < val02){
			System.out.println("val01 < val02");
		}
	}

}
