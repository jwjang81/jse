package cmm03.flow;

public class No01_BlockDemo {
	public static void main(String[] args) {
		boolean condition = true;
		
		if(condition){
			System.out.println("참");
		}
		
		else{
			System.out.println("거짓");
		}
	}

}
