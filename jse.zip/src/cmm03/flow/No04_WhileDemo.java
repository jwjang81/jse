package cmm03.flow;

public class No04_WhileDemo {
	public static void main(String[] args) {
		int count = 1;
		while (count < 11) {
			
			System.out.println("회전수는 "
					+count + "번 입니다.");
			
			count++;
			
		}
	}

}
