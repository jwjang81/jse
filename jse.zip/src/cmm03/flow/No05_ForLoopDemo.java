package cmm03.flow;

public class No05_ForLoopDemo {
	public static void main(String[] args) {
		int a = 0;
		for(int i = 1; i < 11; i++){
			a++;
			System.out.println("a의 값은" + a + " ");
			System.out.println("회전수는" + i + "번 입니다.");
		}
	}

}
