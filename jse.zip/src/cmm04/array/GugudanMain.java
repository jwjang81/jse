package cmm04.array;

public class GugudanMain {

		public static void main(String[] args) {
			GugudanVO gugudan =new GugudanVO();
			gugudan.calc();
		}
}
