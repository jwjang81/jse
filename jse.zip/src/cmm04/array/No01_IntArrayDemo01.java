package cmm04.array;

public class No01_IntArrayDemo01 {
	public static void main(String[] args) {
		int [] intArr;
		intArr = new int[10]; // 배열을 칸막이로 나눈다는 개념
		int i=0;
		
		intArr[0] = 100;
		intArr[1] = 200;
		intArr[2] = 300;
		intArr[3] = 400;
		intArr[4] = 500;
		intArr[5] = 600;
		intArr[6] = 700;
		intArr[7] = 800;
		intArr[8] = 900;
		intArr[9] = 1000;
		intArr[10] = 1100;
		
		
		
	}

}
