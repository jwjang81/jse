package cmm04.array;

public class No01_IntArrayDemo02 {
	public static void main(String[] args) {
		int[] intArr = {100,200,300,400,500,600,700,800,900,1000};
		
		for(int i = 0 ; i < 10 ; i++){
			System.out.println("배열출력"+intArr[i]);
		}
	
	}

}
