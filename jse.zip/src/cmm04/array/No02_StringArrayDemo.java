package cmm04.array;

public class No02_StringArrayDemo {
	public static void main(String[] args) {
		String[] juso = new String[3];
		juso[0] = "서울";
		juso[1] = "종로";
		juso[2] = "광화문";
	}

}
