package cmm04.array;

public class No05_GugudanDemo {
	public static void main(String[] args) {
		
		for(int var = 2 ; var < 10 ; var++){
			System.out.println(var +"단");
			for(int i = 1; i<10; i++ ){
			
				System.out.println(var +"*"+ i + "=" + var*i);
				}
			System.out.println();
		}
	}

}
