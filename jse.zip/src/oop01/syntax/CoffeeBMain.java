package oop01.syntax;

public class CoffeeBMain {
	public static void main(String[] args) {
		CoffeeB coffeeBBB = new CoffeeB(500, true);
	}

}
