package oop02.inhebitance;
/*
 Date : 2015. 5. 22
 Author : 이재우
 Desc : 상속금지 키워드인 final 에 대한 문법
 * */
/*
 final
 1. final 클래스(abstract class)
 - final 클래스는 상속될 수 없음
 2. final 메소드
 - 자식 클래스가 overriding 할 수 없음
 * */
public class FinalSyntax {

}
