package oop04.polymorphism;

public interface FruitInterface {
	public void display(String s);
}
