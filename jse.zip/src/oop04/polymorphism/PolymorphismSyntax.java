package oop04.polymorphism;
/*
 Date : 2015. 5. 26
 Author : 이재우
 Desc : 오버로딩, 오버라이딩
 * */
/*
다형성은 프로그램에서 특별한 연산자나 키워드가 있는 것이 아니며
객체지향  프로그래밍 언어에서 "오버로딩 (overloading)",
"오버라이딩 (overriding)"의 형태로 나타난다.
오버로딩은 메소드 중복정의,
오버라이딩은 멧드 재정의를 뜻한다.
*/
public class PolymorphismSyntax {

}
