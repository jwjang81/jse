package oop05.packages;
/*
패키지 처리 및 패키지 간 참조
- import 사용
- 다른 패키지를 가져다 사용할 경우 선언
- 참고할 패키지의 경로를 지정
- 경로상 어떤 패키지를 참조할 것인지 지정하는 명령어.
*/
public class ImportSyntax {

}
