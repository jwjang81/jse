package oop07.nestedClass;

public interface InnerClassAnonyService {
	void printData();
}